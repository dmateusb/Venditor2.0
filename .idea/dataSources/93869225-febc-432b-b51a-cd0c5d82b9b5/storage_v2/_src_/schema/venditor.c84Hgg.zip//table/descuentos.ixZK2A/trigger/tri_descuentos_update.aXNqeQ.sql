create definer = root@localhost trigger TRI_DESCUENTOS_UPDATE
    before update
    on descuentos
    for each row
BEGIN
    IF NEW.ID<>OLD.ID THEN
        INSERT INTO registro_modificacion( TABLA_MODIFICADA, Fecha, Usario_operacion, Columna_modificada,
                                           Valor_antiguo, Valor_nuevo, ID_MODIFICADO)VALUES (
                                                                                                'DESCUENTOS',sysdate(),user(),'ID',
                                                                                                OLD.ID,new.ID,old.ID);
    end if;
    IF NEW.numero_contrato<>OLD.numero_contrato THEN
        INSERT INTO registro_modificacion( TABLA_MODIFICADA, Fecha, Usario_operacion, Columna_modificada,
                                           Valor_antiguo, Valor_nuevo, ID_MODIFICADO)VALUES (
                                                                                                'DESCUENTOS',sysdate(),user(),'numero_contrato',
                                                                                                OLD.numero_contrato,new.numero_contrato,old.ID);
    end if;
    IF NEW.precio_real<>OLD.precio_real THEN
        INSERT INTO registro_modificacion( TABLA_MODIFICADA, Fecha, Usario_operacion, Columna_modificada,
                                           Valor_antiguo, Valor_nuevo, ID_MODIFICADO)VALUES (
                                                                                                'DESCUENTOS',sysdate(),user(),'precio_real',
                                                                                                OLD.precio_real,new.precio_real,old.ID);
    end if;
    IF NEW.precio_cobrado<>OLD.precio_cobrado THEN
        INSERT INTO registro_modificacion( TABLA_MODIFICADA, Fecha, Usario_operacion, Columna_modificada,
                                           Valor_antiguo, Valor_nuevo, ID_MODIFICADO)VALUES (
                                                                                                'DESCUENTOS',sysdate(),user(),'precio_cobrado',
                                                                                                OLD.precio_cobrado,new.precio_cobrado,old.ID);
    end if;
    IF NEW.razon<>OLD.razon THEN
        INSERT INTO registro_modificacion( TABLA_MODIFICADA, Fecha, Usario_operacion, Columna_modificada,
                                           Valor_antiguo, Valor_nuevo, ID_MODIFICADO)VALUES (
                                                                                                'DESCUENTOS',sysdate(),user(),'razon',
                                                                                                OLD.razon,new.razon,old.ID);
    end if;
    IF NEW.usuario<>OLD.usuario THEN
        INSERT INTO registro_modificacion( TABLA_MODIFICADA, Fecha, Usario_operacion, Columna_modificada,
                                           Valor_antiguo, Valor_nuevo, ID_MODIFICADO)VALUES (
                                                                                                'DESCUENTOS',sysdate(),user(),'usuario',
                                                                                                OLD.usuario,new.usuario,old.ID);
    end if;
end;

