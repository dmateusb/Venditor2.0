create definer = root@localhost trigger TRI_DESCUENTOS_INSERT
    before insert
    on descuentos
    for each row
BEGIN
    INSERT INTO
        registro_adicion (TABLA, ID_VALOR_AÑADIDO, FECHA, USUARIO_OPERACION)
    VALUES('DESCUENTOS',new.Id,sysdate(),user());
end;

