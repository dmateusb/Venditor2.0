create definer = root@localhost trigger TRI_CLIENTES_INSERT
    before insert
    on clientes
    for each row
BEGIN
    INSERT INTO
        registro_adicion (TABLA, ID_VALOR_AÑADIDO, FECHA, USUARIO_OPERACION)
    VALUES('CLIENTES',new.Cedula,sysdate(),user());
end;

