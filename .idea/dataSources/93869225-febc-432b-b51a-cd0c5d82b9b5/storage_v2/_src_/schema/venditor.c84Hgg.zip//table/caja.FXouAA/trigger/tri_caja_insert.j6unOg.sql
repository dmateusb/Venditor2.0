create definer = root@localhost trigger TRI_CAJA_INSERT
    before insert
    on caja
    for each row
BEGIN
    INSERT INTO
        registro_adicion (TABLA, ID_VALOR_AÑADIDO, FECHA, USUARIO_OPERACION)
    VALUES('CAJA',new.Id,sysdate(),user());
end;

