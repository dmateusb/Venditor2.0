create definer = root@localhost trigger TRI_CAJA_UPDATE
    before update
    on caja
    for each row
BEGIN
    IF NEW.id<>OLD.id THEN
        INSERT INTO registro_modificacion( TABLA_MODIFICADA, Fecha, Usario_operacion, Columna_modificada,
                                           Valor_antiguo, Valor_nuevo, ID_MODIFICADO)VALUES (
                                                                                                'CAJA',sysdate(),user(),'id',OLD.id,new.id,old.Id   );
    end if;
    IF NEW.fecha<>OLD.fecha THEN
        INSERT INTO registro_modificacion( TABLA_MODIFICADA, Fecha, Usario_operacion, Columna_modificada,
                                           Valor_antiguo, Valor_nuevo, ID_MODIFICADO)VALUES (
                                                                                                'CAJA',sysdate(),user(),'fecha',OLD.fecha,new.fecha,old.Id   );
    end if;
    IF NEW.descripcion<>OLD.descripcion THEN
        INSERT INTO registro_modificacion( TABLA_MODIFICADA, Fecha, Usario_operacion, Columna_modificada,
                                           Valor_antiguo, Valor_nuevo, ID_MODIFICADO)VALUES (
                                                                                                'CAJA',sysdate(),user(),'descripcion',OLD.descripcion,new.descripcion,old.Id   );
    end if;
    IF NEW.ingreso<>OLD.ingreso THEN
        INSERT INTO registro_modificacion( TABLA_MODIFICADA, Fecha, Usario_operacion, Columna_modificada,
                                           Valor_antiguo, Valor_nuevo, ID_MODIFICADO)VALUES (
                                                                                                'CAJA',sysdate(),user(),'ingreso',OLD.ingreso,new.ingreso,old.Id   );
    end if;
    IF NEW.egreso<>OLD.egreso THEN
        INSERT INTO registro_modificacion( TABLA_MODIFICADA, Fecha, Usario_operacion, Columna_modificada,
                                           Valor_antiguo, Valor_nuevo, ID_MODIFICADO)VALUES (
                                                                                                'CAJA',sysdate(),user(),'egreso',OLD.egreso,new.egreso,old.Id   );
    end if;
    IF NEW.utilidad<>OLD.utilidad THEN
        INSERT INTO registro_modificacion( TABLA_MODIFICADA, Fecha, Usario_operacion, Columna_modificada,
                                           Valor_antiguo, Valor_nuevo, ID_MODIFICADO)VALUES (
                                                                                                'CAJA',sysdate(),user(),'utilidad',OLD.utilidad,new.utilidad,old.Id   );
    end if;
    IF NEW.total<>OLD.total THEN
        INSERT INTO registro_modificacion( TABLA_MODIFICADA, Fecha, Usario_operacion, Columna_modificada,
                                           Valor_antiguo, Valor_nuevo, ID_MODIFICADO)VALUES (
                                                                                                'CAJA',sysdate(),user(),'total',OLD.total,new.total,old.Id   );
    end if;
    IF NEW.usuario<>OLD.usuario THEN
        INSERT INTO registro_modificacion( TABLA_MODIFICADA, Fecha, Usario_operacion, Columna_modificada,
                                           Valor_antiguo, Valor_nuevo, ID_MODIFICADO)VALUES (
                                                                                                'CAJA',sysdate(),user(),'usuario',OLD.usuario,new.usuario,old.Id   );
    end if;
end;

