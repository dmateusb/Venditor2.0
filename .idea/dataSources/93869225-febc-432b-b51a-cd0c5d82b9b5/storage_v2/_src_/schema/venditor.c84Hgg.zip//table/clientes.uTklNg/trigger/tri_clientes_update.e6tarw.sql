create definer = root@localhost trigger TRI_CLIENTES_UPDATE
    before update
    on clientes
    for each row
BEGIN
    IF NEW.Cedula<>OLD.CEDULA THEN
        INSERT INTO registro_modificacion( TABLA_MODIFICADA, Fecha, Usario_operacion, Columna_modificada,
                                           Valor_antiguo, Valor_nuevo, ID_MODIFICADO)VALUES (
                                                                                                'CLIENTES',sysdate(),user(),'cedula',OLD.Cedula,new.Cedula,old.Cedula   );
    end if;
    IF NEW.nombre<>OLD.nombre THEN
        INSERT INTO registro_modificacion( TABLA_MODIFICADA, Fecha, Usario_operacion, Columna_modificada,
                                           Valor_antiguo, Valor_nuevo, ID_MODIFICADO)VALUES (
                                                                                                'CLIENTES',sysdate(),user(),'nombre',OLD.nombre,new.nombre,old.Cedula   );
    end if;
    IF NEW.apellidos<>OLD.apellidos THEN
        INSERT INTO registro_modificacion( TABLA_MODIFICADA, Fecha, Usario_operacion, Columna_modificada,
                                           Valor_antiguo, Valor_nuevo, ID_MODIFICADO)VALUES (
                                                                                                'CLIENTES',sysdate(),user(),'apellidos',OLD.apellidos,new.apellidos,old.Cedula   );
    end if;
    IF NEW.direccion<>OLD.direccion THEN
        INSERT INTO registro_modificacion( TABLA_MODIFICADA, Fecha, Usario_operacion, Columna_modificada,
                                           Valor_antiguo, Valor_nuevo, ID_MODIFICADO)VALUES (
                                                                                                'CLIENTES',sysdate(),user(),'direccion',OLD.direccion,new.direccion,old.Cedula   );
    end if;
    IF NEW.telefono1<>OLD.telefono1 THEN
        INSERT INTO registro_modificacion( TABLA_MODIFICADA, Fecha, Usario_operacion, Columna_modificada,
                                           Valor_antiguo, Valor_nuevo, ID_MODIFICADO)VALUES (
                                                                                                'CLIENTES',sysdate(),user(),'telefono1',OLD.telefono1,new.telefono1,old.Cedula   );
    end if;
    IF NEW.telefono2<>OLD.telefono2 THEN
        INSERT INTO registro_modificacion( TABLA_MODIFICADA, Fecha, Usario_operacion, Columna_modificada,
                                           Valor_antiguo, Valor_nuevo, ID_MODIFICADO)VALUES (
                                                                                                'CLIENTES',sysdate(),user(),'telefono2',OLD.telefono2,new.telefono2,old.Cedula   );
    end if;
    IF NEW.correo<>OLD.correo THEN
        INSERT INTO registro_modificacion( TABLA_MODIFICADA, Fecha, Usario_operacion, Columna_modificada,
                                           Valor_antiguo, Valor_nuevo, ID_MODIFICADO)VALUES (
                                                                                                'CLIENTES',sysdate(),user(),'correo',OLD.correo,new.correo,old.Cedula   );
    end if;
    IF NEW.perfil<>OLD.perfil THEN
        INSERT INTO registro_modificacion( TABLA_MODIFICADA, Fecha, Usario_operacion, Columna_modificada,
                                           Valor_antiguo, Valor_nuevo, ID_MODIFICADO)VALUES (
                                                                                                'CLIENTES',sysdate(),user(),'perfil',OLD.perfil,new.perfil,old.Cedula   );
    end if;
    IF NEW.huella<>OLD.huella THEN
        INSERT INTO registro_modificacion( TABLA_MODIFICADA, Fecha, Usario_operacion, Columna_modificada,
                                           Valor_antiguo, Valor_nuevo, ID_MODIFICADO)VALUES (
                                                                                                'CLIENTES',sysdate(),user(),'huella',OLD.huella,new.huella,old.Cedula   );
    end if;
    IF NEW.foto<>OLD.foto THEN
        INSERT INTO registro_modificacion( TABLA_MODIFICADA, Fecha, Usario_operacion, Columna_modificada,
                                           Valor_antiguo, Valor_nuevo, ID_MODIFICADO)VALUES (
                                                                                                'CLIENTES',sysdate(),user(),'foto',OLD.foto,new.foto,old.Cedula   );
    end if;
    IF NEW.fecha_registro<>OLD.fecha_registro THEN
        INSERT INTO registro_modificacion( TABLA_MODIFICADA, Fecha, Usario_operacion, Columna_modificada,
                                           Valor_antiguo, Valor_nuevo, ID_MODIFICADO)VALUES (
                                                                                                'CLIENTES',sysdate(),user(),'fecha_registro',OLD.fecha_registro,new.fecha_registro,old.Cedula   );
    end if;
    IF NEW.usuario<>OLD.usuario THEN
        INSERT INTO registro_modificacion( TABLA_MODIFICADA, Fecha, Usario_operacion, Columna_modificada,
                                           Valor_antiguo, Valor_nuevo, ID_MODIFICADO)VALUES (
                                                                                                'CLIENTES',sysdate(),user(),'usuario',OLD.usuario,new.usuario,old.Cedula   );
    end if;
end;

