create definer = root@localhost trigger TRI_CONTRATOS_INSERT
    before insert
    on contratos
    for each row
BEGIN
    INSERT INTO
        registro_adicion (TABLA, ID_VALOR_AÑADIDO, FECHA, USUARIO_OPERACION)
    VALUES('CONTRATOS',new.Numero_contrato,sysdate(),user());
end;

