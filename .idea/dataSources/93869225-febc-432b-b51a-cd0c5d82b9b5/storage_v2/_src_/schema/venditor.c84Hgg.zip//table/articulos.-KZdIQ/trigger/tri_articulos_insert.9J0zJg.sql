create definer = root@localhost trigger TRI_ARTICULOS_INSERT
    before insert
    on articulos
    for each row
BEGIN
    INSERT INTO
        registro_adicion (TABLA, ID_VALOR_AÑADIDO, FECHA, USUARIO_OPERACION)
    VALUES('articulos',new.Id,sysdate(),user());
end;

